//
//  ViewController.swift
//  BitcoinTicker
//
//  Created by Angela Yu on 23/01/2016.
//  Updated by Jamisyed on 13/4/2020
//  Copyright © 2016 London App Brewery. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import ProgressHUD
class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate{
   
    
  
    
    let baseURL = "https://apiv2.bitcoinaverage.com/indices/global/ticker/BTC"
    let currencyArray = ["AUD", "BRL","CAD","CNY","EUR","GBP","HKD","IDR","ILS","INR","JPY","MXN","NOK","NZD","PLN","RON","RUB","SEK","SGD","USD","ZAR"]
    let currenySym = ["$", "R$", "$", "¥", "€", "£", "$", "Rp", "₪", "₹", "¥", "$", "kr", "$", "zł", "lei", "₽", "kr", "$", "$", "R"]
    var finalURL = ""
    var currencyPicked = ""
    
    // SIGN UP bitcoinaverage & get YOUR API & then paste it here!
    
    let API_KEY: String = "ZDU3Y2YyYTQ4YjViNDY2YzhkNWQ3NGExOWM0MTgyNzA"
    
    
    //Pre-setup IBOutlets
    @IBOutlet weak var bitcoinPriceLabel: UILabel!
    @IBOutlet weak var currencyPicker: UIPickerView!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        currencyPicker.delegate = self
        currencyPicker.dataSource = self
        
       
    }

    
    //TODO: Place your 3 UIPickerView delegate methods here
    
    
    

    
    
    
//    
//    //MARK: - Networking
//    /***************************************************************/
//    
    func getCurrencyValue(url: String, header: HTTPHeaders) {
        
        ProgressHUD.show("Loading")
       
        
        Alamofire.request(url, method: .get, headers: header).responseJSON{
            response in
            
            ProgressHUD.dismiss()
            
            if response.result.isSuccess{
                self.bitcoinPriceLabel.font = self.bitcoinPriceLabel.font.withSize(54)
                let json: JSON = JSON(response.result.value!)
                
                self.upDatePrice(json : json)
                
            }
            else {
                
                self.bitcoinPriceLabel.font = self.bitcoinPriceLabel.font.withSize(25)
                self.bitcoinPriceLabel.text = "Connectivity issue!"
                
            }
            
            
        }
   }
//
//    
//    
//    
//    
//    //MARK: - JSON Parsing
//    /***************************************************************/
//    
    func upDatePrice(json : JSON) {
        
        if let tempResult = json["low"].double {
           // tempResult = Double(tempResult).roundTo
            bitcoinPriceLabel.text = currencyPicked + (String(format: "%.2f", tempResult))
        
      
  }
    }
//    

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
          return 1
      }
      
      func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
          currencyArray.count
      }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return currencyArray[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        currencyPicked = currenySym[row]
        let header: HTTPHeaders = ["x-ba-key" : API_KEY]
        finalURL = baseURL + currencyArray[row]
        getCurrencyValue(url: finalURL, header: header)
    }
}

